/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: att_kf_types.h
 *
 * MATLAB Coder version            : 5.1
 * C/C++ source code generated on  : 25-Nov-2020 21:15:25
 */

#ifndef ATT_KF_TYPES_H
#define ATT_KF_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for att_kf_types.h
 *
 * [EOF]
 */
